# 机制与时间核组合图代码

说明分别位于 `01-机制分析/原始数据/README.md` 和 `03-时间核/原始数据/README.md`。本包不包含正式模型或实验数据，不会自动训练。

正式绘图后，可在已有 PyMuPDF 的环境使用以下命令复查：

```bash
python _vendor/audit_figure_collisions.py "01-机制分析/输出图片/mechanism_composite.pdf"
python _vendor/audit_figure_collisions.py "03-时间核/输出图片/temporal_kernels_composite.pdf"
python _vendor/audit_pdf_text.py "01-机制分析/输出图片/mechanism_composite.pdf" --min-pt 5
python _vendor/audit_pdf_text.py "03-时间核/输出图片/temporal_kernels_composite.pdf" --min-pt 5
```
