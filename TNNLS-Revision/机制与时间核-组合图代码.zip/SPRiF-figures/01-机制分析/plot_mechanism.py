"""Composite mechanism figure from two actual SI-DMS network trajectories."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parent))
from publication import COLORS, label, save_figure, set_style, require_matplotlib_panel_alignment

STYLE = {"font.family": "sans-serif", "svg.fonttype": "none", "pdf.fonttype": 42}
FORMATS = (".pdf", ".svg", ".png")


def load_data(path, allow_smoke=False):
    with np.load(path, allow_pickle=False) as z:
        keys = ["threshold", "metadata_json"]
        keys += [f"{m}_{k}" for m in ("sprif", "reset")
                 for k in ("x_pre", "x_post", "h_pre", "h_post", "u_pre", "u_post", "spike")]
        missing = sorted(set(keys) - set(z.files))
        if missing:
            raise ValueError(f"{path}: missing fields {missing}")
        d = {key: np.array(z[key]) for key in keys}
        event_key = "event_mask" if "event_mask" in z.files else "forced"
        if event_key not in z.files:
            raise ValueError("Missing event_mask")
        d["events"] = np.array(z[event_key])
        if "dt_ms" in z.files:
            d["dt_ms"] = np.array(z["dt_ms"])
    meta = json.loads(str(d["metadata_json"]))
    if meta.get("format") not in {"sidms-actual-network-trajectories-v1", "benchmark-reconstructed-network-trajectories-v1"}:
        raise ValueError("Expected a supported actual paired-network trajectory export")
    if meta.get("smoke") and not allow_smoke:
        raise ValueError("Smoke data cannot be plotted as formal data")
    events = d["events"]
    if events.ndim != 2 or events.dtype.kind != "b" or not events.any():
        raise ValueError("event_mask must be a nonempty boolean [time, neuron] array")
    shape = events.shape
    theta = float(d["threshold"])
    if not np.isfinite(theta) or theta <= 0:
        raise ValueError("threshold must be positive")
    if "dt_ms" in d and (not np.isfinite(float(d["dt_ms"])) or float(d["dt_ms"]) <= 0):
        raise ValueError("dt_ms must be positive if present")
    for m in ("sprif", "reset"):
        for k in ("x_pre", "x_post", "h_pre", "h_post", "u_pre", "u_post", "spike"):
            a = d[f"{m}_{k}"]
            expected = (*shape, 3) if k.startswith("x_") else shape
            if a.shape != expected or not np.isfinite(a).all():
                raise ValueError(f"Invalid {m}_{k}: expected finite {expected}")
        spike = d[f"{m}_spike"] > .5
        if not np.all(spike[events]):
            raise ValueError(f"{m}: selected event without a spike")
        if not np.allclose(d[f"{m}_u_post"] - d[f"{m}_u_pre"], -theta * spike, atol=2e-5):
            raise ValueError(f"{m}: membrane reset does not match threshold")
        if not np.allclose(d[f"{m}_h_pre"], d[f"{m}_h_post"], atol=2e-5):
            raise ValueError(f"{m}: auxiliary state changed at reset")
        dx = d[f"{m}_x_post"] - d[f"{m}_x_pre"]
        expected = theta * spike if m == "reset" else np.zeros_like(spike, dtype=float)
        if not np.allclose(np.linalg.norm(dx, axis=-1), expected, atol=2e-5):
            raise ValueError(f"{m}: spectral reset does not match the declared model")
    return d, meta


def select_event(forced, radius, event_step, neuron):
    if radius < 1:
        raise ValueError("--radius must be positive")
    n_time, n_units = forced.shape
    if (event_step is None) != (neuron is None):
        raise ValueError("Provide --event-step and --neuron together")
    if event_step is not None:
        if not (radius <= event_step < n_time - radius and 0 <= neuron < n_units and forced[event_step, neuron]):
            raise ValueError("Selected event must be present in event_mask and have a full window")
        return event_step, neuron
    candidates = np.argwhere(forced)
    candidates = candidates[(candidates[:, 0] >= radius) & (candidates[:, 0] < n_time - radius)]
    if not len(candidates):
        raise ValueError("No selected event has the requested full window")
    return tuple(map(int, candidates[0]))


def build(d, meta, event_step, neuron, radius):
    set_style(STYLE)
    fig = plt.figure(figsize=(8.4, 4.8))
    grid = fig.add_gridspec(2, 12, left=.075, right=.975, bottom=.19, top=.91, hspace=.86, wspace=1.8)
    a1 = fig.add_subplot(grid[0, :5]); a2 = fig.add_subplot(grid[1, :5], sharex=a1)
    b = fig.add_subplot(grid[0, 5:8]); c = fig.add_subplot(grid[1, 5:8])
    dd = fig.add_subplot(grid[0, 8:12]); e = fig.add_subplot(grid[1, 8:12])
    for ax, name in zip((a1, a2, b, c, dd, e), ("a_top", "a_bottom", "b", "c", "d", "e")):
        ax.set_gid(name)
    sl = slice(event_step - radius, event_step + radius + 1)
    t = np.arange(-radius, radius + 1)
    theta = float(d["threshold"])
    for j, (color, text) in enumerate(zip(("#276b8c", "#a65328", "#755994"), ("real", "rotation 1", "rotation 2"))):
        a1.plot(t, d["sprif_x_post"][sl, neuron, j], color=color, label=text, lw=1.2)
        a1.scatter([0], [d["sprif_x_pre"][event_step, neuron, j]], s=10, marker="o", color=color, zorder=4)
    a1.axvline(0, color="#777777", lw=.7, ls="--")
    a1.set(title="SPRiF spectral state", ylabel="state")
    a1.tick_params(labelbottom=False)
    a1.legend(loc="upper center", bbox_to_anchor=(.5, -.07), ncol=3,
              frameon=False, handlelength=1.2, columnspacing=.65)
    label(a1, "a")
    for key, ls, name in (("u_pre", "--", "before reset"), ("u_post", "-", "after reset")):
        a2.plot(t, d[f"sprif_{key}"][sl, neuron], color=COLORS["SPRiF"], ls=ls, lw=1.2, label=name)
    a2.axvline(0, color="#777777", lw=.7, ls="--")
    event_name = "forced spike" if meta.get("event_type", "forced") == "forced" else "simultaneous spike"
    a2.set(xlabel=f"Steps relative to {event_name}", ylabel="membrane")
    a2.legend(loc="best", frameon=False)
    for m, display in (("sprif", "SPRiF"), ("reset", "MEMORY_RESET5")):
        xy = d[f"{m}_x_post"][sl, neuron, 1:3]
        b.plot(xy[:, 0], xy[:, 1], color=COLORS[display], lw=1.1, label=display)
        before = d[f"{m}_x_pre"][event_step, neuron, 1:3]
        after = d[f"{m}_x_post"][event_step, neuron, 1:3]
        b.scatter([before[0]], [before[1]], color=COLORS[display], s=16, marker="o")
        b.scatter([after[0]], [after[1]], color=COLORS[display], s=20, marker="x")
    b.set(title="Phase trajectories", xlabel="rotation 1", ylabel="rotation 2")
    fig.legend(handles=[Line2D([0], [0], color=COLORS[name], label=name, lw=1.2)
                        for name in ("SPRiF", "MEMORY_RESET5")],
               loc="lower center", bbox_to_anchor=(.5, .012), ncol=2, frameon=False)
    label(b, "b")
    for m, display in (("sprif", "SPRiF"), ("reset", "MEMORY_RESET5")):
        delta = (d[f"{m}_x_post"][event_step, neuron] - d[f"{m}_x_pre"][event_step, neuron]) / theta
        c.scatter(delta[0], delta[1], s=35, color=COLORS[display], label=display)
        if np.linalg.norm(delta[:2]) > 1e-8:
            c.annotate("", xy=delta[:2], xytext=(0, 0),
                       arrowprops=dict(arrowstyle="->", color=COLORS[display], lw=1))
    c.axhline(0, color="#bbbbbb", lw=.5); c.axvline(0, color="#bbbbbb", lw=.5)
    c.set(title="Spectral reset vector", xlabel="real reset / θ", ylabel="rotation 1 reset / θ")
    label(c, "c")
    mask = d["events"]
    component_means = []
    for i, (m, display) in enumerate((("sprif", "SPRiF"), ("reset", "MEMORY_RESET5"))):
        dx = (d[f"{m}_x_post"] - d[f"{m}_x_pre"])[mask] / theta
        dh = (d[f"{m}_h_post"] - d[f"{m}_h_pre"])[mask, None] / theta
        du = (d[f"{m}_u_post"] - d[f"{m}_u_pre"])[mask, None] / theta
        norm = np.linalg.norm(dx, axis=1)
        offsets = np.linspace(-.11, .11, len(norm))
        dd.scatter(i + offsets, norm, s=9, alpha=.6, color=COLORS[display], linewidths=0)
        component_means.append(np.concatenate((dx, dh, du), axis=1).mean(axis=0))
    dd.set_xticks([0, 1], ["SPRiF", "RESET5"])
    dd.set(title=f"Selected events (n={mask.sum()})", ylabel="spectral reset norm / θ", ylim=(-.12, 1.2))
    label(dd, "d")
    mat = np.array(component_means)
    e.imshow(mat, cmap="coolwarm", vmin=-1, vmax=1, aspect="auto")
    e.set_xticks(range(5), ["real", "rot. 1", "rot. 2", "filter", "mem."], rotation=35, ha="right", rotation_mode="anchor")
    e.set_yticks(range(2), ["SPRiF", "RESET5"])
    e.set_title("Mean reset change / threshold")
    for i in range(2):
        for j in range(5):
            e.text(j, i, f"{mat[i, j]:.2f}", ha="center", va="center", fontsize=6,
                   color="white" if abs(mat[i, j]) > .65 else "black")
    label(e, "e")
    return fig, mat


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", type=Path, default=BASE / "原始数据" / "trajectories.npz")
    p.add_argument("--output", type=Path, default=BASE / "输出图片")
    p.add_argument("--event-step", type=int); p.add_argument("--neuron", type=int)
    p.add_argument("--radius", type=int, default=15)
    p.add_argument("--allow-smoke", action="store_true")
    args = p.parse_args()
    data, meta = load_data(args.input, args.allow_smoke)
    step, neuron = select_event(data["events"], args.radius, args.event_step, args.neuron)
    fig, means = build(data, meta, step, neuron, args.radius)
    base = args.output / "mechanism_composite"
    require_matplotlib_panel_alignment(
        fig, json_out=str(base) + ".alignment.json", strict=True,
        row_groups=[{"id": "top", "panels": ["a_top", "b", "d"]},
                    {"id": "bottom", "panels": ["a_bottom", "c", "e"]}],
        column_groups=[{"id": "left", "panels": ["a_top", "a_bottom"]},
                       {"id": "middle", "panels": ["b", "c"]},
                       {"id": "right", "panels": ["d", "e"]}])
    save_figure(fig, base, formats=FORMATS, dpi=600)
    report = {"input": str(args.input), "source": meta, "event_step": step, "neuron": neuron,
              "selection": "first event in event_mask with complete window" if args.event_step is None else "explicit",
              "radius_steps": args.radius, "selected_neuron_events": int(data["events"].sum()),
              "mean_reset_components_over_selected_events": means.tolist(),
              "note": "One trial with identical input; independently trained networks. Units are not functionally matched."}
    (args.output / "mechanism_composite.source.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Saved mechanism composite; event step={step}, neuron={neuron}")


if __name__ == "__main__":
    main()
