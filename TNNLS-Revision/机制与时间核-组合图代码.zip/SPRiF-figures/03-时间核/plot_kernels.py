"""Old-layout temporal-kernel composite using current-model parameters."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parent))
from common import parameters
from publication import label, save_figure, set_style, require_matplotlib_panel_alignment

STYLE = {"font.family": "sans-serif", "svg.fonttype": "none", "pdf.fonttype": 42}
FORMATS = (".pdf", ".svg", ".png")


def responses(p, steps):
    """Mode-resolved input-to-drive and total no-reset membrane impulse responses."""
    n = len(p["alpha"])
    x = np.zeros((n, 3)); hr = np.zeros(n); ho = np.zeros(n); u = np.zeros(n)
    real = np.empty((n, steps)); rotation = np.empty_like(real); membrane = np.empty_like(real)
    a, r, w, eta, g = p["alpha"], p["rho"], p["omega"], p["eta"], p["bar_G"]
    for t in range(steps):
        impulse = 1.0 if t == 0 else 0.0
        x = np.stack((a*x[:, 0] + (1-a)*impulse,
                      r*(np.cos(w)*x[:, 1] - np.sin(w)*x[:, 2]) + (1-r)*impulse,
                      r*(np.sin(w)*x[:, 1] + np.cos(w)*x[:, 2])), axis=1)
        real[:, t] = g[:, 0, 0]*x[:, 0] + hr
        rotation[:, t] = np.sum(g[:, 0, 1:]*x[:, 1:], axis=1) + ho
        u = eta[:, 0]*u + real[:, t] + rotation[:, t]
        membrane[:, t] = u
        hr = eta[:, 1]*hr + g[:, 1, 0]*x[:, 0]
        ho = eta[:, 1]*ho + np.sum(g[:, 1, 1:]*x[:, 1:], axis=1)
    return {"real": real, "rotation": rotation, "total": real+rotation, "membrane": membrane}


def load_manifest(path):
    manifest = json.loads(path.read_text(encoding="utf-8-sig"))
    groups = manifest.get("groups", [])
    comparisons = manifest.get("comparisons", [])
    if len(groups) != 3 or len(comparisons) != 2:
        raise ValueError("Manifest requires exactly three groups and two ASRNN comparisons for the original layout")
    labels = [g.get("label") for g in groups]
    if any(not isinstance(x, str) or not x.strip() for x in labels) or len(set(labels)) != 3:
        raise ValueError("Each group needs a unique nonempty label")
    if len({c.get("group") for c in comparisons}) != 2 or any(c.get("group") not in labels for c in comparisons):
        raise ValueError("The two comparisons must reference distinct group labels")
    for item in [*groups, *comparisons]:
        key = "parameters" if "label" in item else "asrnn"
        if not isinstance(item.get(key), str) or not item[key].strip():
            raise ValueError(f"Missing {key} path")
        item[key] = (path.parent / item[key]).resolve()
        if not item[key].is_file():
            raise FileNotFoundError(f"Missing source data: {item[key]}")
    return groups, comparisons


def load_asrnn(path):
    with np.load(path, allow_pickle=False) as z:
        alpha = np.asarray(z["alpha"], dtype=float)
        dt = float(z["dt_ms"]) if "dt_ms" in z else None
    if alpha.ndim != 1 or not alpha.size or not np.all(np.isfinite(alpha) & (alpha > 0) & (alpha < 1)):
        raise ValueError(f"{path}: ASRNN alpha must be finite [N] and in (0, 1)")
    return alpha, dt


def peak_normalize(values):
    peak = float(np.max(np.abs(values)))
    if peak <= 1e-12:
        raise ValueError("A selected response is zero and cannot be normalized")
    return values / peak


def spectrum_stats(total):
    spectrum = np.abs(np.fft.rfft(total, axis=1))
    maxima = spectrum.max(axis=1)
    nonzero = maxima > 1e-12
    if not np.any(nonzero):
        raise ValueError("Every neuron has a zero response; normalized spectrum is undefined")
    normal = spectrum[nonzero] / maxima[nonzero, None]
    return np.median(normal, axis=0), *np.quantile(normal, [.1, .9], axis=0), int((~nonzero).sum())


def source_metadata(path, allow_smoke):
    sidecar = path.with_suffix(".json")
    if not sidecar.is_file():
        return {"provenance_status": "metadata sidecar missing; source not verified"}
    meta = json.loads(sidecar.read_text(encoding="utf-8-sig"))
    if meta.get("smoke") is True and not allow_smoke:
        raise ValueError(f"Smoke data cannot be plotted as formal data: {path}")
    return meta


def build(groups, comparisons, steps, allow_smoke=False):
    set_style(STYLE)
    fig = plt.figure(figsize=(8.4, 4.8))
    outer = fig.add_gridspec(2, 12, left=.075, right=.975, bottom=.19, top=.9,
                             height_ratios=[1.05, .95], hspace=.68, wspace=1.1)
    top = outer[0, :].subgridspec(1, 3, wspace=.38)
    bottom = outer[1, :8].subgridspec(1, 3, wspace=.48)
    axes_top = [fig.add_subplot(top[0, i]) for i in range(3)]
    axes_freq = [fig.add_subplot(bottom[0, i]) for i in range(3)]
    ax_compare = fig.add_subplot(outer[1, 8:12])
    for i, ax in enumerate(axes_top): ax.set_gid(f"top{i}")
    for i, ax in enumerate(axes_freq): ax.set_gid(f"freq{i}")
    ax_compare.set_gid("compare")
    quantiles = (.1, .4, .7, .9)
    colors = ("#325d79", "#42859b", "#a07c53", "#7b5085")
    task_colors = ("#325d79", "#a65328", "#755994")
    outputs = {}; provenance = []; results = {}
    for i, item in enumerate(groups):
        source = source_metadata(item["parameters"], allow_smoke)
        p = parameters(item["parameters"])
        res = responses(p, steps)
        results[item["label"]] = (p, res, i, source)
        ax = axes_top[i]
        selected = [int(np.argmin(np.abs(p["alpha"] - np.quantile(p["alpha"], q)))) for q in quantiles]
        for q, index, color in zip(quantiles, selected, colors):
            ax.plot(res["real"][index], color=color, lw=1.1, label=f"q{int(q*100)}")
            ax.plot(res["rotation"][index], color=color, ls=":", lw=1.1)
        ax.axhline(0, color="#bbbbbb", lw=.5)
        ax.set(title=item["label"], xlabel="Step")
        if i == 0:
            ax.set_ylabel("Drive kernel")
            ax.legend(loc="best", ncol=2, frameon=False, title="Real: solid; rotation: dotted", title_fontsize=6)
            label(ax, "a")
        freq = np.fft.rfftfreq(steps)
        median, lo, hi, excluded = spectrum_stats(res["total"])
        f = axes_freq[i]
        f.fill_between(freq, lo, hi, color=task_colors[i], alpha=.2, lw=0)
        f.plot(freq, median, color=task_colors[i], lw=1.2)
        f.set(title=item["label"], xlabel="Cycles / step", xlim=(0, .5), ylim=(0, 1.03))
        if i == 0:
            f.set_ylabel("Normalized |FFT|")
            label(f, "b")
        for name, values in res.items(): outputs[f"group{i}_{name}"] = values
        outputs[f"group{i}_alpha"] = p["alpha"]
        outputs[f"group{i}_selected_indices"] = np.array(selected)
        outputs[f"group{i}_frequency"] = freq
        outputs[f"group{i}_fft_median"] = median
        outputs[f"group{i}_fft_q10"] = lo
        outputs[f"group{i}_fft_q90"] = hi
        provenance.append({"label": item["label"], "parameters": str(item["parameters"]), "source": source,
                           "neurons": len(p["alpha"]), "selected_quantiles": quantiles,
                           "selected_indices": selected, "zero_spectra_excluded": excluded})
    comp_meta = []
    for comp in comparisons:
        p, res, group_index, sprif_source = results[comp["group"]]
        source = source_metadata(comp["asrnn"], allow_smoke)
        asrnn_alpha, dt = load_asrnn(comp["asrnn"])
        sprif_dt = sprif_source.get("dt_ms")
        if dt is not None and sprif_dt is not None and not np.isclose(float(dt), float(sprif_dt)):
            raise ValueError(f"{comp['group']}: SPRiF and ASRNN have different time steps")
        neuron = int(np.argmin(np.abs(p["alpha"] - np.median(p["alpha"]))))
        base_neuron = int(np.argmin(np.abs(asrnn_alpha - p["alpha"][neuron])))
        sprif = peak_normalize(res["membrane"][neuron])
        a = asrnn_alpha[base_neuron]
        baseline = peak_normalize((1-a) * np.power(a, np.arange(steps)))
        color = task_colors[group_index]
        ax_compare.plot(sprif, color=color, lw=1.2, label=f"{comp['group']} SPRiF")
        ax_compare.plot(baseline, color=color, ls="--", lw=1.2, label=f"{comp['group']} ASRNN")
        outputs[f"comparison{len(comp_meta)}_sprif_membrane"] = sprif
        outputs[f"comparison{len(comp_meta)}_asrnn_membrane"] = baseline
        comp_meta.append({"group": comp["group"], "asrnn": str(comp["asrnn"]), "dt_ms": dt, "source": source,
                          "sprif_neuron": neuron, "asrnn_neuron": base_neuron,
                          "selection": "SPRiF median alpha; nearest ASRNN alpha"})
    ax_compare.axhline(0, color="#bbbbbb", lw=.5)
    ax_compare.set(title="No-spike membrane response", xlabel="Step", ylabel="Peak-normalized")
    ax_compare.legend(loc="upper center", bbox_to_anchor=(.5, -.35), ncol=2, frameon=False,
                      fontsize=6, columnspacing=.8, handlelength=1.5)
    label(ax_compare, "c")
    return fig, outputs, {"groups": provenance, "comparisons": comp_meta,
                          "steps": steps, "frequency_band": "per-neuron normalized; median and 10th–90th percentiles",
                          "note": "Responses are local, zero-state, unit-current and no-spike; no recurrent propagation."}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", type=Path, default=BASE / "原始数据" / "manifest.json")
    p.add_argument("--steps", type=int, default=200)
    p.add_argument("--output", type=Path, default=BASE / "输出图片")
    p.add_argument("--allow-smoke", action="store_true", help="Development only; not a formal figure")
    args = p.parse_args()
    if args.steps < 2:
        raise ValueError("--steps must be at least 2")
    groups, comparisons = load_manifest(args.manifest)
    fig, data, meta = build(groups, comparisons, args.steps, args.allow_smoke)
    base = args.output / "temporal_kernels_composite"
    require_matplotlib_panel_alignment(
        fig, json_out=str(base) + ".alignment.json", strict=True,
        row_groups=[{"id": "top", "panels": ["top0", "top1", "top2"]},
                    {"id": "bottom", "panels": ["freq0", "freq1", "freq2"]}],
        column_groups=[])
    save_figure(fig, base, formats=FORMATS, dpi=600)
    np.savez(args.output / "temporal_kernels_composite.data.npz", **data)
    (args.output / "temporal_kernels_composite.source.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"Saved {args.output / 'temporal_kernels_composite.pdf'}")


if __name__ == "__main__":
    main()
