from __future__ import annotations

import random

import numpy as np
import torch
from torch.nn import functional as F

from .config import ExperimentConfig
from .data import make_batch
from .models import SIDMSNetwork

def seed_everything(seed: int):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def resolve_device(value: str):
    return "cuda" if value == "auto" and torch.cuda.is_available() else ("cpu" if value == "auto" else value)

def train_model(name: str, cfg: ExperimentConfig, seed: int, device: str | None = None,
                progress=None, tnnls_protocol=False):
    seed_everything(seed)
    device = resolve_device(device or cfg.train.device)
    model = SIDMSNetwork(name, cfg).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.train.learning_rate)
    history = []
    rng = random.Random(seed)
    # Separate schedule streams prevent training condition from changing delay order.
    delay_rng = random.Random(5_000_000_000_000 + seed) if tnnls_protocol else rng
    count_rng = random.Random(6_000_000_000_000 + seed) if tnnls_protocol else rng
    report_every = max(1, cfg.train.steps // 20)

    clean_delay = cfg.task.train_delays_ms[len(cfg.task.train_delays_ms) // 2]
    clean_batch = make_batch(cfg, cfg.train.batch_size, clean_delay, 0,
                             cfg.model.hidden_size, seed=(2_000_000_000_000 + seed*1_000_000 if tnnls_protocol else seed * 7_777_777), device=device,
                             fraction=0.0)

    @torch.no_grad()
    def clean_acc():
        model.eval()
        out = model(clean_batch.x, clean_batch.intervention)
        acc = float((out.logits.argmax(-1) == clean_batch.y).float().mean())
        model.train()
        return acc

    model.train()
    for step in range(cfg.train.steps):
        delay = delay_rng.choice(cfg.task.train_delays_ms)
        count = count_rng.choice(cfg.task.train_intervention_counts)
        batch = make_batch(cfg, cfg.train.batch_size, delay, count,
                           cfg.model.hidden_size, seed=(1_000_000_000_000 + seed*1_000_000 + step if tnnls_protocol else seed * 1_000_003 + step), device=device,
                           fraction=cfg.task.train_intervention_fraction,
                           mask_seed=(7_000_000_000_000 + seed*1_000_000 + step if tnnls_protocol else None))
        out = model(batch.x, batch.intervention)
        ce = F.cross_entropy(out.logits, batch.y)
        rate_loss = (out.natural_rate_tensor - cfg.train.rate_target).square()
        loss = ce + cfg.train.rate_weight * rate_loss
        optimizer.zero_grad(); loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.train.grad_clip)
        optimizer.step()
        row = {"step": step + 1, "loss": float(loss.detach()),
               "accuracy": float((out.logits.argmax(-1) == batch.y).float().mean()),
               "natural_rate": out.natural_rate, "delay_ms": delay,
               "intervention_count": count}
        is_report = (step == 0 or (step + 1) % report_every == 0 or step + 1 == cfg.train.steps)
        if is_report:
            row["clean_accuracy"] = clean_acc()
        history.append(row)
        if progress is not None:
            progress(row)
    return model, history

@torch.no_grad()
def evaluate_grid(model: SIDMSNetwork, cfg: ExperimentConfig, seed: int, batches: int = 20,
                  batch_size: int | None = None, device: str | None = None, progress=None, paired=False):
    device = resolve_device(device or cfg.train.device)
    model.to(device).eval(); batch_size = batch_size or cfg.train.batch_size
    rows = []
    fractions = cfg.task.eval_intervention_fractions
    for d_i, delay in enumerate(cfg.task.eval_delays_ms):
        for k_i, count in enumerate(cfg.task.eval_intervention_counts):

            frac_list = [(0, 0.0)] if count == 0 else list(enumerate(fractions))
            for f_i, frac in frac_list:
                correct = total = 0; rates = []; hits = []
                for b in range(batches):
                    batch_seed = (3_000_000_000_000 + seed*1_000_000 + d_i*10_000 + b if paired
                                  else seed * 10_000_019 + d_i * 100_003 + k_i * 1009 + f_i * 131 + b)
                    mask_seed = (4_000_000_000_000 + seed*1_000_000 + d_i*10_000 + b if paired else None)
                    batch = make_batch(cfg, batch_size, delay, count, cfg.model.hidden_size,
                                       seed=batch_seed, device=device, fraction=frac, mask_seed=mask_seed)
                    out = model(batch.x, batch.intervention)
                    correct += int((out.logits.argmax(-1) == batch.y).sum()); total += batch_size
                    rates.append(out.natural_rate); hits.append(out.forced_hit_rate)
                row = {"model": model.name, "seed": seed, "delay_ms": delay,
                       "intervention_count": count, "intervention_fraction": frac,
                       "accuracy": correct / total,
                       "natural_rate": sum(rates) / len(rates),
                       "forced_hit_rate": sum(hits) / len(hits)}
                rows.append(row)
                if progress is not None: progress(row)
    return rows

